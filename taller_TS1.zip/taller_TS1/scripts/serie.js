var Serie = /** @class */ (function () {
    function Serie(id, nombre, canal, temporadas, descripcion, link, poster) {
        this.id = id;
        this.nombre = nombre;
        this.canal = canal;
        this.temporadas = temporadas;
        this.descripcion = descripcion;
        this.link = link;
        this.poster = poster;
    }
    return Serie;
}());
export { Serie };
